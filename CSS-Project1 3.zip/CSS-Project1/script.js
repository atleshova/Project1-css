window.addEventListener('scroll', () => {
    const headerFixed = document.querySelector('.header__fixed');
    const scrollPosition = window.scrollY;

    headerFixed.style.backgroundColor = scrollPosition > 0 ? 'white' : 'transparent';
});

window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    const headerFixed = document.querySelector('.header__fixed');
    if (window.scrollY > 0) {
        header.classList.add('sticky');
    } else {
        header.classList.remove('sticky');
    }
});

const metrics = document.querySelectorAll('.metric');

metrics.forEach(metric => {
    const target = +metric.querySelector('.number').dataset.target;
    const percentage = metric.querySelector('.number').dataset.percentage === 'true';
    const numberSpan = metric.querySelector('.number');

    let currentNumber = 0;
    const increment = Math.ceil(target / 50);

    function updateNumber() {
        currentNumber += increment;
        if (currentNumber > target) {
            currentNumber = target;
        }

        numberSpan.textContent = percentage ? currentNumber + '%' : currentNumber;

        if (currentNumber < target) {
            requestAnimationFrame(updateNumber);
        }
    }

    let animationTriggered = false;

    const observer = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting && !animationTriggered) {
            updateNumber();
            animationTriggered = true;
        }
    });

    observer.observe(metric);

    if (metric.getBoundingClientRect().top < window.innerHeight) {
        updateNumber();
        animationTriggered = true;
    }
});


document.addEventListener('DOMContentLoaded', () => {

    const reasonsGrid = document.querySelector('.reasons__grid');

    if (!reasonsGrid) { 
        console.error("Element with class 'reasons__grid' not found.");
        return; 
    }

    let animationTriggered = false;

    const observer = new IntersectionObserver(entries => {
        if (entries.isIntersecting &&!animationTriggered) {
            reasonsGrid.classList.add('reasons__grid--animated');
            animationTriggered = true;
        }
    }, { threshold: 0.5 });


    observer.observe(reasonsGrid);

    if (reasonsGrid.getBoundingClientRect().top < window.innerHeight) {
        reasonsGrid.classList.add('reasons__grid--animated');
        animationTriggered = true;
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const serviceItems = document.querySelectorAll('.services__item');

    serviceItems.forEach(item => {
        const subtitle = item.querySelector('.services__subtitle');
        const counterContainer = item.querySelector('.counter-container');

        if (subtitle && counterContainer) {
            subtitle.addEventListener('mouseover', () => {
                counterContainer.classList.add('counter-container--hover');
            });

            subtitle.addEventListener('mouseout', () => {
                counterContainer.classList.remove('counter-container--hover');
            });

            counterContainer.addEventListener('mouseover', () => {
                counterContainer.classList.add('counter-container--hover');
            });

            counterContainer.addEventListener('mouseout', () => {
                counterContainer.classList.remove('counter-container--hover');
            });
        }
    });
});