window.addEventListener('scroll', () => {
    const headerFixed = document.querySelector('.header__fixed');
    const scrollPosition = window.scrollY;

    headerFixed.style.backgroundColor = scrollPosition > 0 ? 'white' : 'transparent';
});

window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    const headerFixed = document.querySelector('.header__fixed');
    if (window.scrollY > 0) {
        header.classList.add('sticky');
    } else {
        header.classList.remove('sticky');
    }
});

const metrics = document.querySelectorAll('.metric');

metrics.forEach(metric => {
    const target = +metric.querySelector('.number').dataset.target;
    const percentage = metric.querySelector('.number').dataset.percentage === 'true';
    const numberSpan = metric.querySelector('.number');

    let currentNumber = 0;
    const increment = Math.ceil(target / 50);

    function updateNumber() {
        currentNumber += increment;
        if (currentNumber > target) {
            currentNumber = target;
        }

        numberSpan.textContent = percentage ? currentNumber + '%' : currentNumber;

        if (currentNumber < target) {
            requestAnimationFrame(updateNumber);
        }
    }

    let animationTriggered = false;

    const observer = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting && !animationTriggered) {
            updateNumber();
            animationTriggered = true;
        }
    });

    observer.observe(metric);

    if (metric.getBoundingClientRect().top < window.innerHeight) {
        updateNumber();
        animationTriggered = true;
    }
});